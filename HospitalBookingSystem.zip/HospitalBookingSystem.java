package com.yourpackage.hospital;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class HospitalBookingSystem extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField nameTextField;
    private JSpinner ageSpinner;
    private JComboBox<String> languageComboBox;
    private JComboBox<String> doctorComboBox;
    private JComboBox<String> timeSlotComboBox;
    private JButton submitButton;

    public HospitalBookingSystem() {
        setTitle("Hospital Booking System");
        setSize(600, 400); // Larger size to accommodate smaller components
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(10, 0));

        JLabel nameLabel = new JLabel("Name:");
        nameTextField = new JTextField();
        add(nameLabel);
        add(nameTextField);
        JLabel ageLabel = new JLabel("Age:");
        SpinnerModel ageModel = new SpinnerNumberModel(18, 0, 150, 1);
        ageSpinner = new JSpinner(ageModel);
        add(ageLabel);
        add(ageSpinner);

        JLabel languageLabel = new JLabel("Language:");
        String[] languages = {"Spanish", "English"};
        languageComboBox = new JComboBox<>(languages);
        add(languageLabel);
        add(languageComboBox);

        JLabel doctorLabel = new JLabel("Doctor Choice:");
        String[] doctors = {"Dermatologist", "Neurosurgeon", "Cardiologist", "Psychiatrist", "Pediatrician", "Orthopedician", "Dentist"};
        doctorComboBox = new JComboBox<>(doctors);
        add(doctorLabel);
        add(doctorComboBox);

        JLabel timeSlotLabel = new JLabel("Time Slot:");
        String[] timeSlots = {"10:00", "11:00", "12:00", "1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00", "8:00", "9:00"};
        timeSlotComboBox = new JComboBox<>(timeSlots);
        add(timeSlotLabel);
        add(timeSlotComboBox);

        submitButton = new JButton("Submit");
        add(submitButton);

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameTextField.getText();
                int age = (int) ageSpinner.getValue();
                String language = (String) languageComboBox.getSelectedItem();
                String doctor = (String) doctorComboBox.getSelectedItem();
                String timeSlot = (String) timeSlotComboBox.getSelectedItem();

                // Write patient details to a text file
                try {
                    FileWriter writer = new FileWriter("patient_details.txt", true);
                    writer.write("Name: " + name + "\n");
                    writer.write("Age: " + age + "\n");
                    writer.write("Language: " + language + "\n");
                    writer.write("Doctor Choice: " + doctor + "\n");
                    writer.write("Time Slot: " + timeSlot + "\n");
                    writer.write("----------------------------------------\n");
                    writer.close();
                    JOptionPane.showMessageDialog(null, "Patient details saved successfully!");
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error saving patient details!");
                }
            }
        });

        // Center the window on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new HospitalBookingSystem();
            }
        });
    }
}
